---
name: Xamarin.Forms - Basic Calculator
description: "A basic calculator app for Android and iOS using Xamarin.Forms"
page_type: sample
languages:
- csharp
products:
- xamarin
urlFragment: liveplayer-basiccalculator
---
# Xamarin.Forms - Basic Calculator

This Xamarin.Forms app provides a simple calculator you can use on your Android or iOS device:

![Calculator app](Screenshots/basic-calculator-sml.png)
